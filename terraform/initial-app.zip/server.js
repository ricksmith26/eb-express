const http = require('http');
const port = process.env.PORT || 8080;

const server = http.createServer((req, res) => {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('Elastic Beanstalk environment ready. Awaiting deployment.\n');
});

server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
